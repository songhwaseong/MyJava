package lineage;

import java.util.Scanner;

public class LineageFunc {

    //시간지연 2초
    public static void threadlike() throws InterruptedException {
        Thread.sleep(2000);
    }

    //action 선택
    public static int choiceAction(Character chat1, Character chat2, Scanner s) throws InterruptedException {
        System.out.print("동작 선택 1.기본공격, 2.스킬, 3.조롱, 4.도망, 5.포션사용, 6.게임종료 ====> ");
        int action = s.nextInt();
        threadlike();
        switch (action){
            case 1:                                                     //공격
                chat1.attack(chat2);
                break;
            case 2:
                System.out.println("스킬이 발동됩니다.");                  //스킬사용
                Action act1 = (Action)chat1;
                act1.skill(chat2);
                break;
            case 3:
                Action act2 = (Action)chat1;                            //조롱
                act2.mockery(chat2);
                break;
            case 4:
                Action act3 = (Action)chat1;                            //도망
                act3.run();
                break;
            case 5:
                chat1.usingPotion();                                    //물약사용
                break;
            case 6:
                System.out.println("게임을 종료합니다.");                 //게임종료
                System.exit(0);
        }

        //체력 0이하면 게임종료
        if(chat1.getStamina() < 1 || chat2.getStamina() < 1){
            if(chat1.getStamina() < 1){
                System.out.println(chat1.getCharacterName() + "이 사망했습니다. ");
                return 2;
            }else if(chat2.getStamina() < 1){
                System.out.println(chat2.getCharacterName() + "이 사망했습니다. ");
                return 1;
            }
        }
        return -1;
    }
}
